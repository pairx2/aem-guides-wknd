/*global document, CQ, $CQ, DQM */
/***
 * Requires:
 * - CQ
 * - $CQ
 */
(function(CQ, $, dqm) {

	var selector = "crownpeakdqm",
		title = "DQM Validation",
		activeStandards;

	function getTitle() {
		return title + (isValidationMode() ? " - enabled" : "");
	}

	function getValidationModeUrl() {
		var url = CQ.shared.HTTP.addSelector(CQ.WCM.getContentUrl(), selector);
		if (CQ.shared.HTTP.getParameter(url, "CP")) {
			return CQ.shared.HTTP.removeParameter(url, "CP");
		}
		return url;
	}

	function isValidationMode() {
		return $.inArray(selector, CQ.shared.HTTP.getSelectors(CQ.WCM.getContentUrl())) !== -1;
	}

	function getNoValidationModeUrl() {
		// strip ActiveStandards selector wisely
		var url = document.createElement('a');
            url.href = CQ.shared.HTTP.addParameter(CQ.WCM.getContentUrl(), "CP", "off");

		var fileName = url.pathname.substring(url.pathname.lastIndexOf("/")),
			newFileName = fileName.replace(new RegExp(selector + ".(.*$)"), "$1");
		url.pathname = url.pathname.replace(fileName, newFileName);

		return url.href;
	}

	function getUrlForValidationMode() {
		return isValidationMode() ? getNoValidationModeUrl() : getValidationModeUrl();
	}

	function toggleValidationMode() {
		var url = getUrlForValidationMode();
		CQ.WCM.getTopWindow().location.href = url;
	}

	function doWhenSidekickReady(callback) {
		if (CQ.WCM.isSidekickReady()) {
			callback();
		} else {
			CQ.WCM.on("editablesready", function() {
				callback();
			});
		}
	}

	function doValidation(force) {

		if (force && CQ.WCM.isSidekickReady()) {
			CQ.Notification.notify(title, "Forcing refresh without cache");
		}

		if (CQ.WCM.isSidekickReady()) {
			CQ.WCM.getSidekick().disable();
		}

		cpdqmIssueRenderer.preparePage();
		$.ajax({
			cache: false,
			url: "/services/crownpeakdqm/" + (force ? "revalidate" : ""),
			dataType: "json"
		}).done(function(data) {

			var notify = function() {
				CQ.WCM.getSidekick().enable();
				cpdqmIssueRenderer.run(data);
			};

			doWhenSidekickReady(notify);

		}).fail(function(jqXHR) {

			var notify = function() {
				// An error has occurred, remove the cpdqmIssueRenderer html items
				cpdqmIssueRenderer.cleanPage();
				var errorData = dqm.handleStatusCode(jqXHR);

				CQ.WCM.getSidekick().enable();

				CQ.Notification.notify(errorData.title, errorData.message, 6);
			};

			doWhenSidekickReady(notify);

		});
	}

	// namespace for exposed public API
	activeStandards = CQ.Ext.namespace('CrownpeakDQM');
	// exposed API members
	activeStandards.IsValidationMode = isValidationMode;
	activeStandards.title = title;
	activeStandards.doValidation = doValidation;


	// init code
	$(document).ready(function() {

		// init button
		CQ.WCM.on('sidekickready', function (sk) {
			sk.on('loadcontent', function(){
				var sidekick = CQ.WCM.getSidekick(),
				pageTab = sidekick.panels.PAGE;

				pageTab.add({
					xtype: "button",
					text: getTitle(),
					handler: toggleValidationMode
				});
				pageTab.doLayout();
			});
		});

		if (isValidationMode()) {
			doValidation();
		}
	});

}(CQ, $CQ, DQM));