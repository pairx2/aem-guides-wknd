/* global CQ, $CQ, CrownpeakDQM */
/***
 * Requires:
 * - CQ
 * - $CQ
 * - CrownpeakDQM.Injector
 */
(function(CQ, $, CrownpeakDQM) {
	var	editBase = CQ.wcm.EditBase,
		revalidate = function() {
			if (CrownpeakDQM.IsValidationMode()) {
				CrownpeakDQM.doValidation();
			}
		},
		listeners = {
			afterEdit: function() {
				revalidate();
			},
			afterCopy: function(editBase, sourcePath, destinationPath) {
				CQ.WCM.onEditableReady(destinationPath, function() { revalidate(); });
			},
			afterChildInsert: function(editBase, componentPath) {
				CQ.WCM.onEditableReady(componentPath, function() { revalidate(); });
			},
			afterDelete : function() {
				revalidate();
			}
		},
		injectedAfter = {
			constructorEnd: function(config) {
				if (!config.isContainer) {
					this.addListener(editBase.EVENT_AFTER_EDIT, listeners.afterEdit);
					this.addListener(editBase.EVENT_AFTER_COPY, listeners.afterCopy);
					this.addListener(editBase.EVENT_AFTER_DELETE, listeners.afterDelete);
				}
				else {
					this.addListener(editBase.EVENT_AFTER_CHILD_INSERT, listeners.afterChildInsert);
				}
			}
		};

	(function() {
		CrownpeakDQM.Injector.injectAfter(CQ.wcm.EditBar, injectedAfter);
		CrownpeakDQM.Injector.injectAfter(CQ.wcm.EditRollover, injectedAfter);
	}());

}(CQ, $CQ, CrownpeakDQM));
