/**
 * Namespace
 */
(function () {
    window.DQM = window.DQM || {};
    window.DQM.templates = {};
})();
