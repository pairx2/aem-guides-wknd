/*global Granite, DQM*/
/**
 * Overlay
 *
 * Inherits from ns.edit.Overlay
 * Adds functions to manage the list of issues that can be displayed on the overlay of an invalid component.
 */
(function ($, ns, dqm) {

    dqm.Overlay = function (editable, container) {
        dqm.Overlay.super_.constructor.call(this, editable, container);
    };

    ns.util.inherits(dqm.Overlay, ns.edit.Overlay);

    function appendIssuesList($refDom, issues) {
        var $issueList = $refDom.find(".dqm-overlay-issues");
        if ($issueList.length) {
            $issueList.empty();
        } else {
            $issueList = $("<div>", {"class": "dqm-overlay-issues"});
        }
        $issueList.html(dqm.templates.overlayIssueList(issues));
        $refDom.append($issueList);
    }

    dqm.Overlay.prototype.setIssues = function (issues) {
        appendIssuesList($(this.dom), issues);
        this.dom.addClass("dqm-is-invalid");
    };

    dqm.Overlay.prototype.clearIssues = function () {
        this.dom.find(".dqm-overlay-issues").empty();
        this.dom.removeClass("dqm-is-invalid");
    };
}(jQuery, Granite.author, DQM));
