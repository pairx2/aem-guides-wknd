this["DQM"] = this["DQM"] || {};
this["DQM"]["templates"] = this["DQM"]["templates"] || {};

Handlebars.registerPartial("generalAccordion", Handlebars.template({"1":function(container,depth0,helpers,partials,data) {
    var stack1, helper, alias1=depth0 != null ? depth0 : (container.nullContext || {}), alias2=helpers.helperMissing, alias3="function", alias4=container.escapeExpression;

  return "        <coral-accordion-item data-issue-name=\""
    + alias4(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"name","hash":{},"data":data}) : helper)))
    + "\">\n            <coral-accordion-item-label>"
    + alias4(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"name","hash":{},"data":data}) : helper)))
    + "</coral-accordion-item-label>\n            <coral-accordion-item-content>\n"
    + ((stack1 = helpers["if"].call(alias1,(depth0 != null ? depth0.sourceHighlightUrl : depth0),{"name":"if","hash":{},"fn":container.program(2, data, 0),"inverse":container.noop,"data":data})) != null ? stack1 : "")
    + "                <a class=\"coral-Icon coral-Icon--infoCircle coral-Icon--sizeS\" id=\"_"
    + alias4(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"id","hash":{},"data":data}) : helper)))
    + "\" title=\"Description\"></a>\n            </coral-accordion-item-content>\n        </coral-accordion-item>\n";
},"2":function(container,depth0,helpers,partials,data) {
    var helper, alias1=depth0 != null ? depth0 : (container.nullContext || {}), alias2=helpers.helperMissing, alias3="function", alias4=container.escapeExpression;

  return "                    <a class=\"coral-Icon coral-Icon--fileCode coral-Icon--sizeS dqm-markup-inspection\"\n                       data-issue-name=\""
    + alias4(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"name","hash":{},"data":data}) : helper)))
    + "\"\n                       data-url=\""
    + alias4(((helper = (helper = helpers.sourceHighlightUrl || (depth0 != null ? depth0.sourceHighlightUrl : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"sourceHighlightUrl","hash":{},"data":data}) : helper)))
    + "\"\n                       title=\"View source\"></a>\n";
},"compiler":[7,">= 4.0.0"],"main":function(container,depth0,helpers,partials,data) {
    var stack1;

  return "<coral-accordion variant=\"large\" multiple>\n"
    + ((stack1 = helpers.each.call(depth0 != null ? depth0 : (container.nullContext || {}),(depth0 != null ? depth0.generalIssues : depth0),{"name":"each","hash":{},"fn":container.program(1, data, 0),"inverse":container.noop,"data":data})) != null ? stack1 : "")
    + "</coral-accordion>";
},"useData":true}));

Handlebars.registerPartial("generalPopover", Handlebars.template({"compiler":[7,">= 4.0.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<coral-popover closable=\"on\" placement=\"bottom\" target=\"#dqm-general-issues-help\">\n    <coral-popover-header>General issues</coral-popover-header>\n    <coral-popover-content>\n        <p class=\"u-coral-margin\">General issues are issues that cannot be highlighted in the browser view.</p>\n        <p class=\"u-coral-margin\">These usually are missing elements or issues that are found in the header, footer, metatags etc.</p>\n        <p class=\"u-coral-margin\">To view these issues highlighted in the source code, click on the \"View source\" button in the list below.</p>\n    </coral-popover-content>\n</coral-popover>";
},"useData":true}));

Handlebars.registerPartial("highlightedAccordion", Handlebars.template({"1":function(container,depth0,helpers,partials,data) {
    var stack1, helper, alias1=depth0 != null ? depth0 : (container.nullContext || {}), alias2=helpers.helperMissing, alias3="function", alias4=container.escapeExpression;

  return "        <coral-accordion-item data-issue-name=\""
    + alias4(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"name","hash":{},"data":data}) : helper)))
    + "\">\n            <coral-accordion-item-label><span>"
    + alias4(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"name","hash":{},"data":data}) : helper)))
    + "</span>\n                <coral-tag color=\"grey\" size=\"S\">"
    + alias4(container.lambda(((stack1 = (depth0 != null ? depth0.components : depth0)) != null ? stack1.length : stack1), depth0))
    + "</coral-tag>\n            </coral-accordion-item-label>\n            <coral-accordion-item-content>\n"
    + ((stack1 = helpers["if"].call(alias1,(depth0 != null ? depth0.sourceHighlightUrl : depth0),{"name":"if","hash":{},"fn":container.program(2, data, 0),"inverse":container.noop,"data":data})) != null ? stack1 : "")
    + "                <a class=\"coral-Icon coral-Icon--infoCircle coral-Icon--sizeS\" id=\"_"
    + alias4(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"id","hash":{},"data":data}) : helper)))
    + "\" title=\"Description\"></a>\n                <ul>\n"
    + ((stack1 = helpers.each.call(alias1,(depth0 != null ? depth0.components : depth0),{"name":"each","hash":{},"fn":container.program(4, data, 0),"inverse":container.noop,"data":data})) != null ? stack1 : "")
    + "                </ul>\n            </coral-accordion-item-content>\n        </coral-accordion-item>\n";
},"2":function(container,depth0,helpers,partials,data) {
    var helper, alias1=depth0 != null ? depth0 : (container.nullContext || {}), alias2=helpers.helperMissing, alias3="function", alias4=container.escapeExpression;

  return "                    <a class=\"coral-Icon coral-Icon--fileCode coral-Icon--sizeS dqm-markup-inspection\"\n                       data-issue-name=\""
    + alias4(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"name","hash":{},"data":data}) : helper)))
    + "\"\n                       data-url=\""
    + alias4(((helper = (helper = helpers.sourceHighlightUrl || (depth0 != null ? depth0.sourceHighlightUrl : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"sourceHighlightUrl","hash":{},"data":data}) : helper)))
    + "\"\n                       title=\"View source\"></a>\n";
},"4":function(container,depth0,helpers,partials,data) {
    var helper, alias1=depth0 != null ? depth0 : (container.nullContext || {}), alias2=helpers.helperMissing, alias3="function", alias4=container.escapeExpression;

  return "                        <li class=\"dqm-show-component\"\n                            data-editable-path=\""
    + alias4(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"id","hash":{},"data":data}) : helper)))
    + "\"\n                            data-inspect-markup-index=\""
    + alias4(((helper = (helper = helpers.inspectMarkupIndex || (depth0 != null ? depth0.inspectMarkupIndex : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"inspectMarkupIndex","hash":{},"data":data}) : helper)))
    + "\"\n                            title=\""
    + alias4(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"id","hash":{},"data":data}) : helper)))
    + "\">\n                            <div>"
    + alias4(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"name","hash":{},"data":data}) : helper)))
    + "</div>\n                        </li>\n";
},"compiler":[7,">= 4.0.0"],"main":function(container,depth0,helpers,partials,data) {
    var stack1;

  return "<coral-accordion variant=\"large\" multiple>\n"
    + ((stack1 = helpers.each.call(depth0 != null ? depth0 : (container.nullContext || {}),(depth0 != null ? depth0.highlightedIssues : depth0),{"name":"each","hash":{},"fn":container.program(1, data, 0),"inverse":container.noop,"data":data})) != null ? stack1 : "")
    + "</coral-accordion>";
},"useData":true}));

Handlebars.registerPartial("highlightedPopover", Handlebars.template({"compiler":[7,">= 4.0.0"],"main":function(container,depth0,helpers,partials,data) {
    return "<coral-popover placement=\"bottom\" target=\"#dqm-highlighted-issues-help\" closable=\"on\">\n    <coral-popover-header>Highlighted issues</coral-popover-header>\n    <coral-popover-content>\n        <p class=\"u-coral-margin\">These issues are highlighted in the browser view and the source code.</p>\n        <p class=\"u-coral-margin\">Click on the component name in the list below to highlight the component in the browser view or click on the \"View source\" button located above the list of components to view it in the source view.</p>\n    </coral-popover-content>\n</coral-popover>";
},"useData":true}));

Handlebars.registerPartial("issuePopover", Handlebars.template({"compiler":[7,">= 4.0.0"],"main":function(container,depth0,helpers,partials,data) {
    var helper, alias1=depth0 != null ? depth0 : (container.nullContext || {}), alias2=helpers.helperMissing, alias3="function", alias4=container.escapeExpression;

  return "<coral-popover closable=\"on\" placement=\"bottom\" target=\"#_"
    + alias4(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"id","hash":{},"data":data}) : helper)))
    + "\">\n    <coral-popover-header>"
    + alias4(((helper = (helper = helpers.category || (depth0 != null ? depth0.category : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"category","hash":{},"data":data}) : helper)))
    + "</coral-popover-header>\n    <coral-popover-content><p class=\"u-coral-margin\">"
    + alias4(((helper = (helper = helpers.description || (depth0 != null ? depth0.description : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"description","hash":{},"data":data}) : helper)))
    + "</p></coral-popover-content>\n</coral-popover>";
},"useData":true}));

this["DQM"]["templates"]["markupInspection"] = Handlebars.template({"compiler":[7,">= 4.0.0"],"main":function(container,depth0,helpers,partials,data) {
    var helper, alias1=depth0 != null ? depth0 : (container.nullContext || {}), alias2=helpers.helperMissing, alias3="function", alias4=container.escapeExpression;

  return "<div class=\"cq-dialog-fullscreen\" id=\"dqm-markup-inspection-dialog\">\n    <nav class=\"dqm-cq-dialog-header u-coral-clearFix coral--dark\">\n        <h2 class=\"coral-Heading coral-Heading--2 u-coral-pullLeft\">"
    + alias4(((helper = (helper = helpers.issueName || (depth0 != null ? depth0.issueName : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"issueName","hash":{},"data":data}) : helper)))
    + "</h2>\n        <div class=\"dqm-cq-dialog-actions u-coral-pullRight\">\n            <button class=\"coral-MinimalButton dqm-markup-inspection-cancel\" title=\"Cancel\" type=\"button\">\n                <i class=\"coral-Icon coral-Icon--close\"></i>\n            </button>\n        </div>\n    </nav>\n    <div class=\"cq-dialog-content coral-FixedColumn\">\n        <div class=\"coral-FixedColumn-column\">\n            <coral-wait id=\"dqm-markup-inspection-loader\" size=\"L\" centered></coral-wait>\n            <iframe frameborder=\"0\" id=\"dqm-markup-inspection-frame\" src=\""
    + alias4(((helper = (helper = helpers.inspectUrl || (depth0 != null ? depth0.inspectUrl : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"inspectUrl","hash":{},"data":data}) : helper)))
    + "\"></iframe>\n        </div>\n    </div>\n</div>";
},"useData":true});

this["DQM"]["templates"]["overlayIssueList"] = Handlebars.template({"1":function(container,depth0,helpers,partials,data) {
    return "    <li>"
    + container.escapeExpression(container.lambda(depth0, depth0))
    + "</li>\n";
},"compiler":[7,">= 4.0.0"],"main":function(container,depth0,helpers,partials,data) {
    var stack1;

  return "<ul>\n"
    + ((stack1 = helpers.each.call(depth0 != null ? depth0 : (container.nullContext || {}),depth0,{"name":"each","hash":{},"fn":container.program(1, data, 0),"inverse":container.noop,"data":data})) != null ? stack1 : "")
    + "</ul>";
},"useData":true});

this["DQM"]["templates"]["sidebar"] = Handlebars.template({"1":function(container,depth0,helpers,partials,data) {
    var stack1, helper, alias1=depth0 != null ? depth0 : (container.nullContext || {}), alias2=helpers.helperMissing, alias3="function", alias4=container.escapeExpression;

  return "    <div class=\"sidepanel-tab-title\">Highlighted issues\n        <a class=\"coral-Icon coral-Icon--helpCircle coral-Icon--sizeXS\"\n           id=\"dqm-highlighted-issues-help\"\n           title=\"What are highlighted issues?\"></a>\n        <coral-tag color=\"grey\" size=\"S\">"
    + alias4(((helper = (helper = helpers.highlightedIssuesCount || (depth0 != null ? depth0.highlightedIssuesCount : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"highlightedIssuesCount","hash":{},"data":data}) : helper)))
    + "</coral-tag>\n    </div>\n"
    + ((stack1 = container.invokePartial(partials.highlightedPopover,depth0,{"name":"highlightedPopover","data":data,"indent":"    ","helpers":helpers,"partials":partials,"decorators":container.decorators})) != null ? stack1 : "")
    + "    <div id=\"dqm-validation-highlighted-issues\">\n"
    + ((stack1 = container.invokePartial(partials.highlightedAccordion,depth0,{"name":"highlightedAccordion","data":data,"indent":"        ","helpers":helpers,"partials":partials,"decorators":container.decorators})) != null ? stack1 : "")
    + ((stack1 = helpers.each.call(alias1,(depth0 != null ? depth0.highlightedIssues : depth0),{"name":"each","hash":{},"fn":container.program(2, data, 0),"inverse":container.noop,"data":data})) != null ? stack1 : "")
    + "    </div>\n    <div class=\"sidepanel-tab-title\">General issues\n        <a class=\"coral-Icon coral-Icon--helpCircle coral-Icon--sizeXS\"\n           id=\"dqm-general-issues-help\"\n           title=\"What are general issues?\"></a>\n        <coral-tag color=\"grey\" size=\"S\">"
    + alias4(((helper = (helper = helpers.generalIssuesCount || (depth0 != null ? depth0.generalIssuesCount : depth0)) != null ? helper : alias2),(typeof helper === alias3 ? helper.call(alias1,{"name":"generalIssuesCount","hash":{},"data":data}) : helper)))
    + "</coral-tag>\n    </div>\n"
    + ((stack1 = container.invokePartial(partials.generalPopover,depth0,{"name":"generalPopover","data":data,"indent":"    ","helpers":helpers,"partials":partials,"decorators":container.decorators})) != null ? stack1 : "")
    + "    <div id=\"dqm-validation-general-issues\">\n"
    + ((stack1 = container.invokePartial(partials.generalAccordion,depth0,{"name":"generalAccordion","data":data,"indent":"        ","helpers":helpers,"partials":partials,"decorators":container.decorators})) != null ? stack1 : "")
    + ((stack1 = helpers.each.call(alias1,(depth0 != null ? depth0.generalIssues : depth0),{"name":"each","hash":{},"fn":container.program(2, data, 0),"inverse":container.noop,"data":data})) != null ? stack1 : "")
    + "    </div>\n";
},"2":function(container,depth0,helpers,partials,data) {
    var stack1;

  return ((stack1 = container.invokePartial(partials.issuePopover,depth0,{"name":"issuePopover","data":data,"indent":"            ","helpers":helpers,"partials":partials,"decorators":container.decorators})) != null ? stack1 : "");
},"4":function(container,depth0,helpers,partials,data) {
    return "    <div class=\"sidepanel-tab-title\">Congratulations, no issues found!</div>\n";
},"compiler":[7,">= 4.0.0"],"main":function(container,depth0,helpers,partials,data) {
    var stack1;

  return ((stack1 = helpers["if"].call(depth0 != null ? depth0 : (container.nullContext || {}),(depth0 != null ? depth0.issuesFound : depth0),{"name":"if","hash":{},"fn":container.program(1, data, 0),"inverse":container.program(4, data, 0),"data":data})) != null ? stack1 : "");
},"usePartial":true,"useData":true});