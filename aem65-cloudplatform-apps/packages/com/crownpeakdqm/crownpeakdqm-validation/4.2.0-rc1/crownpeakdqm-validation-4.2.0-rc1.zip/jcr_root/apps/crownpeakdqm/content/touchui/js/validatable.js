/*global Granite, DQM*/
/**
 * Validatable
 * - wraps ns.Editable and overrides updateConfig to prevent any actions being available for the overlay
 *
 * Inheritance details:
 * ns.Inspectable -> ns.Editable -> dqm.Validatable
 */
(function (ns, dqm) {
    dqm.Validatable = ns.util.extendClass(ns.Editable, {

        constructor: function (config, dom) {
            dqm.Validatable.super_.constructor.call(this, config, dom);

            this.config = config ? config : this._originalConfig;
            this.config.editConfig = {actions: []};
            this.config.childConfig = {actions: []};
            this.dropTargets = [];
        },

        updateConfig: function () {
            // no config update intentionally
        },

        hasActionsAvailable: function () {
            // override intentionally
        }
    });
}(Granite.author, DQM));
